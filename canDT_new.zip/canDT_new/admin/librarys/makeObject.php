<?php
//Khởi tạo các dối tượng trong model cart
$getData_model = new GetData();
//$cart_model = new Cart();

//Khởi tạo các đối tương jtrong model sign
//$sign_model = new Sign();

///Khởi tạo các đối tương jtrong model product
//$product_model = new Product();

$search_model = new Search();
/*$_SESSION['fullname']='';
$_SESSION['addr']='';
$_SESSION['tel']='';
$_SESSION['email']=''; */
?>