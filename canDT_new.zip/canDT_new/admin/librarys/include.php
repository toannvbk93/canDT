
<?php
//load config 
require_once('config.php');

//load thư viện các hàm bổ trợ 
require_once('librarys/function.php');
require_once('model/getData/model.php');
require_once('model/search/model.php');



?>