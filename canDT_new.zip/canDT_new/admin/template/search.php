<div id="page-wrapper">
<div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-12 pull-right">
        <form action="index.php?controller=search" method="POST">
          <div class="input-group">
            <input type="text" class="form-control" name="search_input" placeholder="Tìm Kiếm"/>
            <span class="input-group-btn">
              <button class="btn btn-default" name="search" type="submit"><i class="glyphicon glyphicon-search"></i>Tìm Kiếm</button>
            </span>
          </div>
          </form>
      </div>
    </div>
</div>
<hr />
</div>