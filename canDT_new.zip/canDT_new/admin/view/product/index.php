<?php require('template/header.php'); ?>
<?php require('template/search.php');?>
<div id="wrapper">
    <div id="page-wrapper">
        <div class="container-fluid">
			<div class="row">
                <div class="col-lg-12">
                	<h1 class="page-header">Sản phẩm</h1>
                    <ol class="breadcrumb">
                        <li>
                            <i class="fa fa-dashboard"></i>  <a href="index.php?controller=dashboard">Bảng điều khiển</a>
                        </li>
                        <li class="active">
                            <i class="fa fa-list-ol"></i> Sản phẩm
                        </li>
                    </ol>
                </div>
                </div>

			<div class="row">
                <div class="col-lg-12"><label><i class="fa fa-upload"></i> <a href="index.php?controller=product&action=add_product">Thêm sản phẩm</a></label></div>
                <div class="col-lg-12">
                    <h2>Bảng sản phẩm</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Mã id</th>
                                    <th>Loại cân</th>
                                    <th>Tên cân</th>
                                    <th>Hình ảnh</th>
                                    <th>Nổi bật</th>
                                    <th>Sửa sản phẩm</th>
                                    <th>Xóa sản phẩm</th>
                                    <th>Mô tả</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php if($products!=null): ?>
     							<?php  foreach($products as $key => $value): ?>
     							<tr>
                                    <td><?php echo $value['id'];?></td>
                                    <td><?php echo $value['loaican'];?></td>
     								<td><?php echo $value['ten'];?></td>
     								<td><a href=""><img src="../<?php echo $value['hinhanh']?>" alt="" width="50" height="50"/> </a></td>
                                    <td><?php echo $value['noibat'];?>
                                        <a href="index.php?controller=product&rule=change&id=<?php echo $value['id'];?>&name=<?php echo $value['ten'];?>&noibat=<?php echo $value['noibat'];?>">Đổi</a>
                                    </td>
                                    <td> <a href="index.php?controller=product&action=change&amp;masp=<?php echo $value['id'];?>">Sửa</a></td>
     								<td><a href="index.php?controller=product&rule=delete&amp;masp=<?php echo $value['id'];?>">Xóa</a></td>
     							    <td><?php echo $value['mota'];?></td>
                                </tr>
     							<?php endforeach ?>
   								<?php endif ?>
 							</tbody>
						</table>
                     </div>
                </div>
			</div>
			<!-- end row -->

		</div>
	</div>
</div>
<div class="panel-footer">
  <div class="text-center">
     <?php echo $pagination;
     //echo $a;?>
  </div>
</div>