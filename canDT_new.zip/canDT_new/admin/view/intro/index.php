<?php require('template/header.php'); ?>
<?php require('template/search.php');?>
<div id="wrapper">
    <div id="page-wrapper">
        <div class="container-fluid">
			<div class="row">
                <div class="col-lg-12">
                	<h1 class="page-header">Giới thiệu</h1>
                    <ol class="breadcrumb">
                        <li>
                            <i class="fa fa-dashboard"></i>  <a href="index.php?controller=dashboard">Bảng điều khiển</a>
                        </li>
                        <li class="active">
                            <i class="fa fa-arrow-cirle-righct"></i> Giới thiệu
                        </li>
                    </ol>
                </div>
                </div>

			<div class="row">
                <div class="col-lg-12"><label><i class="fa fa-upload"></i> <a href="index.php?controller=intro&action=add_intro">Thêm Giới thiệu</a></label></div>
                <div class="col-lg-12">
                    <h2>Bảng giới thiệu</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Nội dung</th>
                                    <th>Sửa</th>
                                    <th>Xóa</th>
                                    <th>Hiện thị trang chủ</th>
                                </tr>
                            </thead>
                            <tbody>
                            	<?php if($products!=null): ?>
     							<?php  foreach($products as $key => $value): ?>
     							<tr>
                      <td><?php echo $value['id'];?></td>
                      <td><?php echo $value['noidung'];?></td>
                      <td> <a href="index.php?controller=intro&action=change&amp;masp=<?php echo $value['id'];?>">Sửa</a></td>
                      <td><a href="index.php?controller=intro&rule=delete&amp;masp=<?php echo $value['id'];?>">Xóa</a></td>
                      <td>
                        <?php echo $value['chon'];?>
                        <?php if($value['chon']=='no'): ?>
                                      <a href="index.php?controller=intro&rule=up&masp=<?php echo $value['id'];?>">Chọn</a>
                                      <?php endif ?>
                                      <?php if($value['chon']=='yes'): ?>
                                      <a href="index.php?controller=intro&rule=down&masp=<?php echo $value['id'];?>">Bỏ chọn</a>
                                      <?php endif ?>

                      </td>
     							</tr>
     							<?php endforeach ?>
   								<?php endif ?>
 							</tbody>
						</table>
                     </div>
                </div>
			</div>
			<!-- end row -->

		</div>
	</div>
</div>
<div class="panel-footer">
  <div class="text-center">
     <?php echo $pagination;
     ?>
  </div>
</div>