<?php $active='Dashboard';
	$user=$getData_model->get_all('taikhoan');
	$user_num=0;
	if(isset($user)){
		foreach ($user as $key => $value) {
			$user_num=$user_num+1	;
		}
	}
	$product=$getData_model->get_all('sanpham');
	$product_num=0;
	if(isset($product)){
		foreach ($product as $key => $value) {
			$product_num++;
		}
	}

	
	$news=$getData_model->get_all('tintuc');
	$news_num=0;
	if(isset($news)){
		foreach ($news as $key => $value) {
			$news_num++;
		}
	}
	$contact=$getData_model->get_all('lienhe');
	$contact_num=0;
	if(isset($contact)){
		foreach ($contact as $key => $value) {
			$contact_num++;
		}
	}
	$intro=$getData_model->get_all('gioithieu');
	$intro_num=0;
	if(isset($intro)){
		foreach ($intro as $key => $value) {
			$intro_num++;
		}
	}
 ?>
<?php require('template/header.php'); ?>
<?php require('view/dashboard/index.php'); ?>