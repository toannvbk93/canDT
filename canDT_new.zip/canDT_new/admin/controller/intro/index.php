<?php
  if (isset($_GET['rule'])&& isset($_GET['masp'])) {
    if ($_GET['rule']=='delete') {
      $masp=escape($_GET['masp']);
      $getData_model->delete('gioithieu','id',$masp);
    }
    if ($_GET['rule']=='up') {
      $getData_model->update('gioithieu','chon','yes','id',$_GET['masp']);
    }
    if ($_GET['rule']=='down') {
      $getData_model->update('gioithieu','chon','no','id',$_GET['masp']);
    }
  }

  $active='intro';
  $limit = 9;
  $url = 'index.php?controller=gioithieu';
  $total_rows = $getData_model->get_number_recored('gioithieu');
  $total = ceil($total_rows/$limit);
  $total = $total > 0 ? $total : 0;
  if(isset($_GET['page']))
   {
   $page = $_GET['page'] >0 ? $_GET['page'] : 1;
    $page = $_GET['page'] <= $total ? $_GET['page'] : 1;
   }
  else $page = 1;
$offset = ($page -1) *$limit;
   $products = $getData_model->get_from_to('gioithieu',$offset,$limit,null,null);
   
   $pagination = pagination($url,$page,$total);
   require('view/intro/index.php');
   ?>