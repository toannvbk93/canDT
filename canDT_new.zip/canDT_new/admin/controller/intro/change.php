<?php
	$active="intro"; 
if (isset($_POST['submit'])) {
	$noidung=escape($_POST['noidung']);
	$masp=escape($_GET['masp']);
	$getData_model->update('lienhe','noidung',$noidung,'id',$masp);
	$success= 'Thay đổi thành công';
}

	if (isset($_GET['masp'])) {
	$masp=escape($_GET['masp']);
	$sp = $getData_model->get_a_record('lienhe','id',$masp);
}else $sp =null;
require('view/intro/change.php');
 ?>