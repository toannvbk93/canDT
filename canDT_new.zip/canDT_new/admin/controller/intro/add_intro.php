<?php
	$active="intro";
	$news=$getData_model->get_all('gioithieu');
	$news_num=0;
	if(isset($news)){
		foreach ($news as $key => $value) {
			$news_num++;
		}
	}
if (isset($_POST['submit'])) {
	$noidung=$_POST['noidung'];
	$id=$news_num+1;
	$gioithieu= array( 'noidung'=>$noidung);
	$getData_model->save('gioithieu',$gioithieu);
	$success="Thêm giới thiệu thành công!";
	$news_num++;
}
require('view/intro/add_intro.php');
 ?>