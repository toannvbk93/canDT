<?php
	$active="product"; 
if (isset($_POST['submit'])) {
	$tensp=escape($_POST['tensanpham']);
	$mota=escape($_POST['mota']);
	$masp=escape($_GET['masp']);
	$loaican=escape($_POST['loaican']);
	//$hinhanh=escape($_GET['hinhanh']);
	
	$getData_model->update('sanpham','ten',$tensp,'id',$masp);
	$getData_model->update('sanpham','mota',$mota,'id',$masp);
	$getData_model->update('sanpham','loaican',$loaican,'id',$masp);
	$success= 'Thay đổi thành công';
}

	if (isset($_GET['masp'])) {
	$masp=escape($_GET['masp']);
	$sp = $getData_model->get_a_record('sanpham','id',$masp);
}else $sp =null;
require('view/product/change.php');
 ?>