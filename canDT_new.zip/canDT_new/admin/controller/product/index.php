<?php
  if (isset($_GET['rule'])&& isset($_GET['masp'])) {
    if ($_GET['rule']=='delete') {
      $masp=escape($_GET['masp']);
      $sp=$getData_model->get_a_record('sanpham','id',$masp);
      $filename='.././'.$sp['hinhanh'];
      $getData_model->delete('sanpham','id',$masp);
      
      unlink($filename);
    }

  }
  if (isset($_GET['rule'])&& isset($_GET['id'])&& isset($_GET['name'])&& isset($_GET['noibat'])) {
    if ($_GET['rule']=='change') {
      $id=escape($_GET['id']);
      $name=escape($_GET['name']);
      $noibat=escape($_GET['noibat']);
      if ($noibat=='0') {
        $getData_model->update_x('sanpham','noibat','1','id',$id,'ten',$name);
      }else{
        $getData_model->update_x('sanpham','noibat','0','id',$id,'ten',$name);
      }
    }
  }
	$active='product';
 ?>
<?php
  $limit = 9;
  $url = 'index.php?controller=product';
  $total_rows = $getData_model->get_number_recored('sanpham');
  $total = ceil($total_rows/$limit);
  $total = $total > 0 ? $total : 0;
  if(isset($_GET['page']))
   {
    $page = $_GET['page'] >0 ? $_GET['page'] : 1;
    $page = $_GET['page'] <= $total ? $_GET['page'] : 1;
   }
  else $page = 1;
$offset = ($page -1) *$limit;
   $products = $getData_model->get_from_to('sanpham',$offset,$limit,null,null);
   
   $pagination = pagination($url,$page,$total);
   require('view/product/index.php');
   echo $filename;
   ?>