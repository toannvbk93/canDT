<?php
	$active="news";
	$news=$getData_model->get_all('tintuc');
	$news_num=0;
	if(isset($news)){
		foreach ($news as $key => $value) {
			$news_num++;
		}
	}
if (isset($_POST['submit'])) {
	$noidung=$_POST['noidung'];
	$ngaytao=$_POST['ngaytao'];
	$id=$news_num+1;
	$tintuc= array('ngaytao'=>$ngaytao, 'noidung'=>$noidung);
	$getData_model->save('tintuc',$tintuc);
	$success="Thêm tin tức thành công!";
	$news_num++;
}
require('view/news/add_news.php');
 ?>