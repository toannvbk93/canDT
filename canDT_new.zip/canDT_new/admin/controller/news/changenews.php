<?php
	$active="news"; 
if (isset($_POST['submit'])) {
	$ngaytao=escape($_POST['ngaytao']);
	$noidung=escape($_POST['noidung']);
	$masp=escape($_GET['masp']);
	
	$getData_model->update('tintuc','ngaytao',$ngaytao,'id',$masp);
	$getData_model->update('tintuc','noidung',$noidung,'id',$masp);
	$success= 'Thay đổi thành công';
}

	if (isset($_GET['masp'])) {
	$masp=escape($_GET['masp']);
	$sp = $getData_model->get_a_record('tintuc','id',$masp);
}else $sp =null;
require('view/news/changenews.php');
 ?>