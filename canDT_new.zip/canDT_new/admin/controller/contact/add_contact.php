<?php
	$active="contact";
	$news=$getData_model->get_all('lienhe');
	$news_num=0;
	if(isset($news)){
		foreach ($news as $key => $value) {
			$news_num++;
		}
	}
if (isset($_POST['submit'])) {
	$noidung=$_POST['noidung'];
	$id=$news_num+1;
	$lienhe= array( 'noidung'=>$noidung);
	$getData_model->save('lienhe',$lienhe);
	$success="Thêm liên hệ thành công!";
	$news_num++;
}
require('view/contact/add_contact.php');
 ?>