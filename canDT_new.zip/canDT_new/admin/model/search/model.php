<?php
class Search extends getData{
	
	function search_data($search_dt){
		$data =$this->get_all('sanpham');
		$data_search = array();
		$search='/'.strU($search_dt).'/';
		foreach ($data as $value){
			if(preg_match($search,strU($value['ten']))==TRUE ||
				preg_match($search,strU($value['mota']))==TRUE ||
				preg_match($search,strU($value['id']))==TRUE ||
				preg_match($search,strU($value['hinhanh']))==TRUE ||
				preg_match($search,strU($value['loaican']))==TRUE 
				)
			{
				$data_search[]=$value;				  
			}
		}
		return $data_search;
	}
}
?>