<?php
$title='Cân xe tải - Hướng dẫn';
    session_start(); 
   require_once('connectDB.php');
?>
<?php 
	

	
      if (!isset($_SESSION['makh'])) {
      # code...
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
      <div class="master-wrapper-main">
               <?php

                  //require('template/slide.php');
                  require('template/col1.php'); 
                  ?>
         <div class="center-2">
            <div class="page topic-page" id="ph-topic">
               <div id="ph-title">
                  <div class="page-title">
                     <h1>Hướng dẫn</h1> <hr>                    
                  </div>
               </div>
               <div class="page-body">
                  <strong>Các cách để liên hệ với chúng tôi</strong>
                  <img src="images/huongdan1.jpg">
               </div>
            </div>  
         </div>
         <div class="text-center" style="margin-top: 150px; margin-left:auto;margin-right:auto; width: 850px;height:300px">
                  <?php //echo $pagination;?>
         </div>
<?php require('template/footer.php');?>