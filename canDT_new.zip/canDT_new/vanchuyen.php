<?php 
$title='Cân xe tải - Vận chuyển';
	session_start();

	require_once('connectDB.php');
      if (!isset($_SESSION['makh'])) {
      # code...
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
      <div class="master-wrapper-main">
               <?php
                  require('template/col1.php'); 
                  ?>
         <div class="center-2">
            <div class="page topic-page" id="ph-topic">
               <div id="ph-title">
                  <div class="page-title">
                     <h1>Vận chuyển</h1>
                  </div>
               </div>
               <div class="page-body">
                  <p><img src="images/vanchuyen.jpg" alt="" /></p>
               </div>
            </div>

    
         </div>
<?php require('template/footer.php');?>