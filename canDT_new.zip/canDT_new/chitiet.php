<?php 
$title='Cân xe tải - Chi tiết';
session_start();
require_once('connectDB.php');
   if (isset($_GET['id'])) {
      $hinhanh=escape($_GET['id']);
      $sp=$database->get_a_record('sanpham','hinhanh',$hinhanh);
      $_SESSION['preview']=$hinhanh;
   }elseif (isset($_SESSION['preview'])) {
      $hinhanh=$_SESSION['preview'];
      $sp=$database->get_a_record('sanpham','hinhanh',$hinhanh);
   }
	if (!isset($_SESSION['makh'])) {
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
      <div class="master-wrapper-main">
               <?php
                  require('template/col1.php'); 
                  ?>
       <div class="center-2">
               <div class="page home-page">
                  <div class="page-body">
                     <div class="product-grid home-page-product-grid">
                        <div class="title">
                           <strong>Thông tin chi tiết</strong>
                        </div>
                        <div style="float:left;margin-left:10px;width:300px;">
                        <?php if(isset($sp)):?>
                        <img width="300" hight="400" src="<?php echo $sp['hinhanh'];?>"><br>
                     </div>
                     <div style="float:left;margin-left:10px;width:300px;text-align: left;">
                        <?php echo '<strong>Tên : </strong> '.$sp['ten'];?><br><br>
                        <?php echo '<strong>Loại : </strong> '.$sp['loaican'];?><br><br>
                        <?php echo '<strong>Mô tả : </strong> '.$sp['mota'];?><br><br>
                        <?php endif ?>
                        <?php if (!isset($sp)) {
                           echo 'Không có sản phẩm';
                        }?>
                     </div>
                                    
                     </div>
                  </div>
               </div>
      </div>

    
         </div>
<?php require('template/footer.php');?>