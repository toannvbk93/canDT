<?php
$title='Cân xe tải - Sản phẩm';
session_start();
require_once('connectDB.php');
if (isset($_GET['canxetai'])) {
    $loaican='Cân xe tải';
    //$active1='active';
 }
 if (isset($_GET['canxetaisanchim'])) {
    $loaican='Cân xe tải sàn chìm';
    //$active1='active';
 } 
 if (isset($_GET['canxetaisannoi'])) {
    $loaican='Cân xe tải sàn nổi';
    //$active1='active';
 } 
 if (isset($_GET['canxetaixachtay'])) {
    $loaican='Cân xe tải xách tay';
    //$active1='active';
 }  
if (isset($_GET['canthuongmai'])) {
    $loaican='Cân thương mại';
    //$active2='active';
 } 
 if (isset($_GET['cancongnghiep'])) {
    $loaican='Cân công nghiệp';
    //$active3='active';
 }
  if (isset($_GET['thietbikhac'])) {
    $loaican='Thiết bị khác';
    //$active4='active';
 }  
 if (isset($_POST['search_input'])) {
   $search_input = escape($_POST['search_input']);
   $products_search = $search_model->search_data($search_input);
 }
$active1=$active2=$active3=$active4="";
	

	
      if (!isset($_SESSION['makh'])) {
      # code...
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
      <div class="master-wrapper-main">
               <?php

                 // require('template/slide.php');
                  require('template/col1.php'); 
                  include('template/show_product.php');
                  ?>

      </div>
<?php require('template/footer.php');?>