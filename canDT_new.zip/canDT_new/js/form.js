
/* Scroll*/
$(window).scroll(function(){
    t = parseInt($(window).scrollTop() + 20);
    $('.contact-wrap, .contact').stop().animate({marginTop:t},400);
});

/* Xuất hiện box form*/
$(document).ready(function() {
    $('a.contact-button').click(function() {
        var contactBox = $(this).attr('href');
        $(contactBox).fadeIn("slow");
        $('body').append('<div id="over"></div>');
        $('#over').fadeIn(300);
        return false;
    });
    $(document).on('click', "a.close, #over", function() { 
        $('#over, .contact').fadeOut(300 , function() {
            $('#over').remove();  
        }); 
        return false;
    });
    $(window).resize(function(){
    t = parseInt($(window).width());
    if (t<=1076) {
        $('.contact-wrap').hide();
    }
    else
        $('.contact-wrap').show();
    
});
	
});


