-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2015 at 08:19 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `can_dt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `gioithieu`
--

CREATE TABLE IF NOT EXISTS `gioithieu` (
  `id` int(11) NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `chon` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gioithieu`
--

INSERT INTO `gioithieu` (`id`, `noidung`, `chon`) VALUES
(2, '<h2 style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; font-family: arial, helvetica, sans-serif; color: rgb(92, 91, 91); line-height: normal; background: transparent;">CAS Việt Nam</h2><p style="color: rgb(92, 91, 91); font-family: arial, helvetica, sans-serif; font-size: 12px;"><strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">CAS CORPORATION</strong>&nbsp;Công Ty tầm cỡ quốc tế, thành lập vào năm 1983 tại Đại Hàn Dân Quốc, chuyên sản xuất các loại cân điện tử, các thiết bị ứng dụng trong lĩnh vực cân và cung cấp các giải pháp cân toàn diện về cân điện tử với bề dầy hoạt động trên 27 năm, sản phẩm đã xuất khẩu ở 120 quốc gia. CAS có trụ sở chính và nhà máy sản xuất tại Hàn Quốc và các nhà máy trực thuộc tại Mỹ, Ấn Độ, Nga, Thổ Nhĩ Kỳ, Trung Quốc và văn phòng đại diện tại nhiều nước khác trên thế giới. Tại Việt Nam văn phòng đại diện được thành lập vào ngày 26 tháng 11 năm 2001 Trong quá trình phát triển, Cân Điện Tử CAS đã xây dựng cho mình nền tảng vững chắc về chất lượng cũng như chế độ phục vụ được khách hàng tin tưởng đánh giá cao. Chúng tôi cam kết cung cấp các giải pháp kỹ thuật hoàn chỉnh với những thiết bị chất lượng cao, và phương châm&nbsp;<strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;"><em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">"Có mặt sau 2h khi nhận được cuộc gọi của quý khách"</em></strong>&nbsp;và bảo đảm dịch vụ hậu mãi tốt....</p><div style="margin: 0px; padding: 0px 10px 0px 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(92, 91, 91); font-family: arial, helvetica, sans-serif; line-height: normal; float: left; width: 220px; background: transparent;"><h2 style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; font-family: arial, helvetica, sans-serif; background: transparent;"><a name="history" style="margin: 0px; padding: 0px; font-size: 1.1em; vertical-align: baseline; color: rgb(184, 7, 9); text-decoration: underline; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"></a>Lịch sử</h2><p style="line-height: 20px;">Từ năm 1989,chúng tôi đã cung cấp,thiết kế lắp đặt, bảo trì và sửa chữa các loại cân điện tử, các hệ thống cân xe tải, cân công nghiệp tự động cho hơn 5000 công ty trên thế giới và tại Việt Nam. Với phương châm&nbsp;<strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;"><em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">"chính xác để thành công"</em></strong>&nbsp;chúng tôi luôn cung cấp&nbsp;<strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;"><em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">"giải pháp toàn diện về cân điện tử"</em></strong>.</p></div><div style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(92, 91, 91); font-family: arial, helvetica, sans-serif; line-height: normal; float: left; width: 560px; background: transparent;"><iframe src="http://www.youtube.com/embed/PYlgTCHlWgE?list=UU5r_d4Jvqa2Y8_wFrK3kqEw" width="560" height="315" frameborder="0" allowfullscreen="allowfullscreen" style="margin: 0px; padding: 0px; border-width: 0px; outline: 0px; vertical-align: baseline; background: transparent;"></iframe></div><div style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(92, 91, 91); font-family: arial, helvetica, sans-serif; line-height: normal; float: left; width: 718px; background: transparent;"><h2 style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; font-family: arial, helvetica, sans-serif; background: transparent;"><a name="vision" style="margin: 0px; padding: 0px; font-size: 1.1em; vertical-align: baseline; color: rgb(184, 7, 9); text-decoration: underline; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"></a>Tầm nhìn</h2><p style="line-height: 20px;">Chúng tôi luôn hướng đến xây dựng công ty Cân Điện Tử CAS tại Việt Nam thành công với tầm nhìn&nbsp;<strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;"><em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">"Trở Thành Thương Hiệu Cân Điện Tử lớn nhất tại Việt Nam"</em></strong>&nbsp;và sứ mệnh&nbsp;<strong style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;"><em style="margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;">"Cân Công Bằng tạo nên uy tín cho xã hội"</em></strong>.</p><p style="line-height: 20px;">Chúng tôi luôn tri ân sự hợp tác của quý vị. Một lần nữa xin chân thành cảm ơn!</p><h2 style="margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; font-family: arial, helvetica, sans-serif; background: transparent;"><a name="casglobal" style="margin: 0px; padding: 0px; font-size: 1.1em; vertical-align: baseline; color: rgb(184, 7, 9); text-decoration: underline; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"></a>CAS toàn cầu</h2><p><img src="http://cas.com.vn/content/images/sv_sub03_01.gif" alt="Cân điện tử CAS, Can dien tu CAS" style="margin: 0px; padding: 0px; outline: 0px; vertical-align: baseline; background: transparent;">&nbsp;<img src="http://cas.com.vn/content/images/sv_sub03_02.gif" alt="Cân điện tử CAS, Can dien tu CAS" style="margin: 0px; padding: 0px; outline: 0px; vertical-align: baseline; background: transparent;">&nbsp;<img src="http://cas.com.vn/content/images/sv_sub03_03.gif" alt="Cân điện tử CAS, Can dien tu CAS" style="margin: 0px; padding: 0px; outline: 0px; vertical-align: baseline; background: transparent;">&nbsp;<img src="http://cas.com.vn/content/images/sv_sub03_04.gif" alt="Cân điện tử CAS, Can dien tu CAS" style="margin: 0px; padding: 0px; outline: 0px; vertical-align: baseline; background: transparent;"></p></div><script>img_find(''contents'');</script> ', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE IF NOT EXISTS `khachhang` (
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `hoten` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` int(11) NOT NULL,
  `makh` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `matk` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `tinnhan` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`email`, `hoten`, `sdt`, `makh`, `matk`, `tinnhan`) VALUES
('hoangtuan@gmail.com', 'hoàn tuấn', 1234567029, 'b5BQlr', '', 'à'),
('ad11906764.vn@gmail.com', 'Nguyễn Văn A', 988886666, 'dOE8sv', '1432057140', 'Số 3 ngõ 4 ...'),
('ad11906764.vn@gmail.com', 'Nguyễn Viết Huỳnh', 988886666, 'JgbtVV', '1431749134', 'Số 3'),
('hiloveithedspi@gmail.com', 'Nguyễn Viết Huỳnh', 988886666, 'M7NtAK', '1432057573', '12'),
('hiloveithedspi@gmail.com', 'Nguyễn Viết Huỳnh', 988886666, 'w4kDlP', '1431718881', 'Số 3');

-- --------------------------------------------------------

--
-- Table structure for table `lienhe`
--

CREATE TABLE IF NOT EXISTS `lienhe` (
  `id` int(11) NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `chon` enum('no','yes') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lienhe`
--

INSERT INTO `lienhe` (`id`, `noidung`, `chon`) VALUES
(1, 'Công ty ABC:<script>img_find(''contents'');</script><div><ol><li>Địa chỉ:</li><li>FAX</li><li>Số điện thoại</li><li>Website</li><li>bla bla</li></ol></div><script>img_find(''contents'');</script>', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE IF NOT EXISTS `sanpham` (
  `id` varchar(20) NOT NULL,
  `ten` varchar(100) NOT NULL,
  `mota` longtext NOT NULL,
  `hinhanh` varchar(100) NOT NULL,
  `loaican` enum('Cân xe tải sàn chìm','Cân xe tải sàn nổi','Cân xe tải xách tay','Cân xe tải di động','Cân công nghiệp','Cân thương mại','Thiết bị khác') NOT NULL,
  `noibat` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `ten`, `mota`, `hinhanh`, `loaican`, `noibat`) VALUES
('Can treo', 'Cân treo', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/can treo.jpg', 'Cân công nghiệp', '0'),
('canchongch', 'Cân chống cháy nổ', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/canchongchay.jpg', 'Cân công nghiệp', '0'),
('cansan', 'Cân sàn', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/can san.jpg', 'Cân công nghiệp', '0'),
('I-300', 'Cân xe tải mẫu I-300 sàn nổi', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Sàn cân được thiết kế khoa học và thẩm mỹ<o:p></o:p></p>\r\n\r\n<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Linh kiện nhập khẩu chính hãng và đồng bộ<o:p></o:p></p><script>img_find(''contents'');</script>', 'images/sanpham/I300 san noi.jpg', 'Cân xe tải sàn nổi', '1'),
('I-300', 'Cân xe tải mẫu I-300 sàn nổi nhập khẩu', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Sàn cân làm bằng thép hình ngoại nhập<o:p></o:p></p>\r\n\r\n<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Linh kiện nhập khẩu chính hãng và đồng bộ<o:p></o:p></p><script>img_find(''contents'');</script>', 'images/sanpham/I300 san noi nhap khau.jpg', 'Cân xe tải sàn nổi', '1'),
('I-600', 'Cân xe tải mẫu I-600 sàn chìm', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Sàn cân chắc chắn và ổn định<o:p></o:p></p>\r\n\r\n<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Tiết kiệm diện tích cho nhà máy,tính thẩm mỹ cao<o:p></o:p></p><script>img_find(''contents'');</script>', 'images/sanpham/I600 san chim.jpg', 'Cân xe tải sàn chìm', '1'),
('I-600', 'Cân xe tải mẫu I-600 sàn nổi', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Dầm chịu lực chính: thép I-600 ngoại nhập<o:p></o:p></p>\r\n\r\n<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Đảm bảo độ bền của sàn cân và độ chính xác,ổn định của\r\nhệ thống<o:p></o:p></p><script>img_find(''contents'');</script>', 'images/sanpham/I600 san noi.jpg', 'Cân xe tải sàn nổi', '1'),
('inhoadon', 'Cân in hóa đơn', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/inhoadon.jpg', 'Cân thương mại', '0'),
('innhan', 'Cân in nhãn', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/innhan.jpg', 'Cân thương mại', '0'),
('ISORT 3GR', 'Máy tách màu thông minh ISORT 3GR thế hệ mới', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Dùng đèn LED độ sáng cao với nhiều dải màu điều chỉnh<o:p></o:p></p><p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Tích hợp camera CCD/NIR<o:p></o:p></p><p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1">\r\n\r\n\r\n\r\n</p><p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Phân loại thành phẩm và phế phẩm các loại hạt : <b>Gạo, Cà phê, Điều, Chè, Ngũ cốc, Nhựa…</b> <o:p></o:p></p><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/ISORT 3GR.jpg', 'Thiết bị khác', '1'),
('LMT', 'Cân xe tải mẫu LMT sàn nổi nhập khẩu', '<p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Nhập khẩu chính hãng từ Hàn Quốc, CO/CQ rõ ràng<o:p></o:p></p><p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1">\r\n\r\n</p><p class="MsoNormal" style="margin-left:.75in;text-indent:-.25in;mso-list:l0 level1 lfo1"><!--[if !supportLists]-->-<span style="font-stretch: normal; font-size: 7pt; line-height: normal; font-family: ''Times New Roman'';">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span><!--[endif]-->Mặt sàn là tôn gân 10mm,sơn epoxy cho độ bền cao<o:p></o:p></p><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/LMT san noi nhap khau.jpg', 'Cân xe tải sàn nổi', '1'),
('Pallet', 'Cân Pallet', 'Chưa có<script>img_find(''contents'');</script>', 'images/sanpham/Pallet.jpg', 'Cân công nghiệp', '0'),
('tinhgia', 'Cân tính giá', 'Chưa có<script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script><script>img_find(''contents'');</script>', 'images/sanpham/tinhgia.jpg', 'Cân thương mại', '0');

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE IF NOT EXISTS `taikhoan` (
  `matk` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `matkhau` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `ngaytao` date NOT NULL,
  `capdo` enum('admin','normal') COLLATE utf8_unicode_ci NOT NULL,
  `kichhoat` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`matk`, `email`, `matkhau`, `ngaytao`, `capdo`, `kichhoat`) VALUES
('1432057140', 'ad11906764.vn@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', '2015-05-20', 'admin', 1),
('1432057573', 'hiloveithedspi@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2015-05-20', 'normal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tintuc`
--

CREATE TABLE IF NOT EXISTS `tintuc` (
  `ngaytao` date NOT NULL,
  `noidung` text COLLATE utf8_unicode_ci NOT NULL,
  `id` int(11) NOT NULL,
  `chon` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gioithieu`
--
ALTER TABLE `gioithieu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`makh`);

--
-- Indexes for table `lienhe`
--
ALTER TABLE `lienhe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`,`ten`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`matk`);

--
-- Indexes for table `tintuc`
--
ALTER TABLE `tintuc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gioithieu`
--
ALTER TABLE `gioithieu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `lienhe`
--
ALTER TABLE `lienhe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tintuc`
--
ALTER TABLE `tintuc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
