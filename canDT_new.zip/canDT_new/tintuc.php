<?php
$title='Cân xe tải - Tin tức';
    session_start();
   require_once('connectDB.php');
  $limit = 9;
  $url = 'tintuc.php';
  $news=$database->get_all('tintuc');
   $news_num=0;
   if(isset($news)){
      foreach ($news as $key => $value) {
         $news_num++;
      }
   }
  $total_rows = $news_num;
  $total = ceil($total_rows/$limit);
  $total = $total > 0 ? $total : 0;
  if(isset($_GET['page']))
   {
    $page = $_GET['page'] >0 ? $_GET['page'] : 1;
    $page = $_GET['page'] <= $total ? $_GET['page'] : 1;
   }
  else $page = 1;
  $offset = ($page -1) *$limit;
   $products = get_from_to('tintuc',$offset,$limit,null,null);
   
   $pagination = pagination($url,$page,$total);
  // require('view/product/index.php');
   ?>

<?php 
	

	
      if (!isset($_SESSION['makh'])) {
      # code...
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
      <div class="master-wrapper-main">
               <?php

                  //require('template/slide.php');
                  require('template/col1.php'); 
                  ?>
         <div class="center-2">
            <div class="page topic-page" id="ph-topic">
               <div id="ph-title">
                  <div class="page-title">
                    <?php if (!isset($_GET['tinmoi'])) {?>
                    <h1>Tin tức</h1> <hr>
                    <?php }else{?>
                    <h1>Tin mới</h1> <hr>
                    <?php }?>
                     
                     
                  </div>
               </div>
               <div class="page-body">
                  <?php
                     $news=$database->get_all('tintuc');
                     $news_max=0;
                     if(isset($news)){
                     foreach ($news as $key => $value) {
                        if ($news_max<$value['id']) {
                           $news_max=$value['id'];
                        }
                        if ($value['chon']=='yes'&&!isset($_GET['tinmoi'])) {
                           echo $value['noidung'];
                        }
                     }
                  }
                  if (isset($_GET['tinmoi'])) {
                    $news=$database->get_a_record('tintuc','id',$news_max);
                    echo $news['noidung'];
                  }
                  if ($news_max==0) {
                     echo 'Không có tin tức gì!';
                  }
                  ?>
                  
               </div>
            </div>  
         </div>
         <div class="text-center" style="margin-top: 150px; margin-left:auto;margin-right:auto; width: 850px;">
                  <?php echo $pagination;?>
         </div>
<?php require('template/footer.php');?>