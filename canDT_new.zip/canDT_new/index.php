<?php 
$title='Cân xe tải - Trang chủ';
$active1=$active2=$active3=$active4="";
	session_start();

	require_once('connectDB.php');
      if (!isset($_SESSION['makh'])) {
      # code...
      $_SESSION['makh']=getCustomerCode();
   }
	require('template/header.php');?>
   
      <div class="master-wrapper-main">
               <?php

                  require('template/slide.php');

                  require('template/col1.php'); 
                  require('template/show_product.php');
                  ?>

      </div>
<?php require('template/footer.php');?>