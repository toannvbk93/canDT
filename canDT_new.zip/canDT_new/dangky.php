<?php 
    $title='Cân xe tải - Đăng ký';
    session_start();
    require_once('connectDB.php');
          if (!isset($_SESSION['makh'])) {
      $_SESSION['makh']=getCustomerCode();
   }
    $erroup='hehe';
    if (isset($_POST['submit'])) {
        $email=escape($_POST['email']);
        $hoten=escape($_POST['fullname']);
        $sdt=escape($_POST['tel']);
        $diachi=escape($_POST['addr']);
        $mk=escape($_POST['password']);
        $mk=md5($mk);
        $matk=getOrderCode();
        $makh=$_SESSION['makh'];
        $check= $sign->checkAvailableAccount($email);
        if ($check==false) {
            $date = gmdate('Y-m-d H:i:s',time() + 7*3600); 
            $capdo ='normal';
            $taikhoan = array('email'=>$email, 'matkhau'=>$mk,'matk'=>$matk, 'kichhoat'=>true,'ngaytao'=>$date, 'capdo'=>$capdo);
            $khachhang = array('makh'=>$makh, 'hoten'=>$hoten, 'tinnhan'=>$diachi, 'email'=>$email, 'sdt'=>$sdt, 'matk'=>$matk);

            $sign->save('taikhoan',$taikhoan);
            $sign->save('khachhang',$khachhang);
            $success='thanh cong';
            session_destroy();
            require('dangky.php');
        }else {$erroup='email da ton tai!';}
    }
        
?>
<?php require('template/header.php');?>
<div class="master-wrapper-main">
               <?php
                  require('template/col1.php'); 
                ?>
    <div class="center-2">
        <?php 
            if (!isset($success)) {
        ?>
    		<div class="page-title">
        		<h1>Xin chào, mời bạn đăng ký !</h1>
    		</div>
    		<div class="page-body">
            	<div class="fieldset">
                	<div class="title">
                    	<strong>Nhập thông tin</strong>
                	</div>
                    <?php 
                        if (isset($erroup)&&$erroup=='email da ton tai!') {
                            echo $erroup.'Mời bạn nhập lại!';
                        }
                    ?>
                	<div class="form-fields">
                		<br>
						<form action="dangky.php" method="post">
	                        <div class="message-error">
                            </div>
                        <div class="inputs">
                            <label for="fullname">Họ tên:</label><br>
                            <input class="text-box single-line" data-val="true" data-val-required="Cần phải nhập" placeholder="vd: Nguyễn Văn A" id="fullname" name="fullname" type="text">
                            <span class="required">*</span>
                            <span class="field-validation-valid" data-valmsg-for="fullname" data-valmsg-replace="true"></span>
                        </div>
                        <br>
                        <div class="inputs">
                            <label for="tel">Số điện thoại:</label><br>
                            <input class="text-box single-line" data-val="true" data-val-regex="Sdt phải là số có 10 hoặc 11 số" data-val-regex-pattern="[0-9]{10,11}" data-val-required="Cần phải nhập" placeholder="vd: 0988886666" id="Tel" name="tel" type="text" required="required">
                            <span class="required">*</span>
                            <span class="field-validation-valid" data-valmsg-for="tel" data-valmsg-replace="true"></span>
                        </div>
                        <br>
                        <div class="inputs">
                            <label for="addr">Địa chỉ:</label><br>
                            <input class="text-box single-line"  placeholder="vd: Số 3 ngõ 4..." id="addr" name="addr" type="text">
                        </div>
                        <br>
                        <div class="inputs"> 
                            <label for="email">Email:</label><br>
                            <input class="text-box single-line" data-val="true" data-val-email="Sai định dạng email" data-val-required="Cần phải nhập" id="email" name="email" type="text" placeholder="vd: cas@gmail.com" >
                            <span class="required">*</span>
                            <span class="field-validation-valid" data-valmsg-for="email" data-valmsg-replace="true"></span>
                        </div>
                        <br>
                        <div class="inputs">
                            <label for="password">Mật khẩu:</label><br><br>
                            <input class="text-box single-line password" data-val="true" data-val-length="Mật khẩu phải có ít nhất 6 kí tự" data-val-length-max="999" data-val-length-min="6" data-val-required="Cần phải nhập" id="password" name="password" type="password" placeholder="Điền mật khẩu vào đây"  />
                            <span class="required">*</span>
                            <span class="field-validation-valid" data-valmsg-for="password" data-valmsg-replace="true"></span>
                        </div>
                        <br>
                        <div class="inputs">
                            <label for="confirmpass">Xác nhận lại mật khẩu:</label><br><br>
                            <input class="text-box single-line password" data-val="true" data-val-equalto="Mật khẩu xác thực không chính xác" data-val-equalto-other="*.password" data-val-required="Cần phải nhập" id="confirmpass" name="confirmpass" type="password" placeholder="Điền mật khẩu vào đây" />
                            <span class="required">*</span>
                            <span class="field-validation-valid" data-valmsg-for="confirmpass" data-valmsg-replace="true"></span>
                        </div>
                        <br><br>
                        <div class="buttons">
                            <input type="submit" id="register-button" class="btn yellow" value="Đăng ký" name="submit" />
                        </div>
				</form>
                </div>
            </div>
        </div>
        <?php 
            }else{
        ?>
        <div class="page-title">
            <h1>Đăng ký thành công, mời bạn đăng nhập!</h1><hr><br>
            <a href="dangnhap.php">Đăng nhập</a>
        </div>
        <?php }?>
    </div>
</div>

<?php require('template/footer.php');?>