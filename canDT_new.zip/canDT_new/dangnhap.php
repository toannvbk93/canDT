<?php
    $title='Cân xe tải - Đăng nhập';
	session_start();
    require('connectDB.php');
	if (isset($_POST['submit'])){
		$email=escape($_POST['Email']);
		$pass=escape($_POST['Password']);
		if (isset($_POST['remeber'])) {
			$remeber=escape($_POST['remeber']);
			if ($remeber==true) {
			setcookie($email,$pass ,time() + (86400 * 30), "/");
			}
		}
		
		$check= $sign->checkSignin($email,$pass);
		if($check==true){
			$_SESSION['email'] =$email;
			$_SESSION['makh'] = $check['makh']; 
			$capdo=$sign->get_a_record('taikhoan','email',$email);
			$_SESSION['capdo']=$capdo['capdo'];
			if ($capdo['capdo']=='admin') {
				header('location:admin/index.php');
			
			}
			else
				header('location:index.php');
		}else{
            $erroin = "Email hoặc mật khẩu không chính xác, vui lòng nhập lại!";
            require('template/signin.php');
        }

	}
    else{
        require('template/signin.php');}
?>
