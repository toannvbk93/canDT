<?php
    class Database{
        const DB_HOSTNAME = 'localhost';
        const DB_USERNAME = 'root';
        const DB_PASSWORD = '';
        const DB_NAME = 'can_dt_db';
        protected $_db_connect;
        protected $sql_user;
        protected $_result;
        protected $_row;
        protected $_sql_deny;
        protected $sql;
		public $row_1;
        function db_connect(){
            $this->_db_connect = mysql_connect(self::DB_HOSTNAME,self::DB_USERNAME,self::DB_PASSWORD) or die(mysql_error());
            mysql_query ("set character_set_results='utf8'");
            mysql_query ("set character_set_client='utf8'");
            mysql_query ("set collation_connection='utf8_general_ci'");
        }
        function select_db(){
            mysql_select_db(self::DB_NAME) or die(mysql_error());
        }
        function sql_show_product(){
            $this->sql_user = "SELECT `ten`, `hinhanh` FROM `sanpham`";
        }
        function query_show_product(){
            $this->_result = mysql_query($this->sql_user);
        }
        function fetch_array_product(){
            $_row = @mysql_fetch_array($this->_result);
            return $this->_row;
        }
        function db_close(){
             mysql_close($this->_db_connect);
        }
        function get_all($table,$select = '*'){
            $sql = "SELECT $select FROM $table";
            $query = mysql_query($sql) or die(mysql_error());
            
            $data = array();
            if(mysql_num_rows($query) >0){
                while($row = mysql_fetch_assoc($query))
                    $data[]= $row;
                return $data;
            }
            else return null;
        }
        function get_a_record($table, $colum, $value , $select = '*') {
            //truy vấn
            $sql = "SELECT $select FROM `$table` WHERE $colum='$value'";
            $query = mysql_query($sql) or die(mysql_error());

            //dữ liệu trả về
            $data = NULL;
            if (mysql_num_rows($query) > 0) {
                $data = mysql_fetch_assoc($query);
                mysql_free_result($query);
            }
             return $data;
          
        }
        function save($table, $data = array()) {
            //xử lý dữ liệu $data
            $values = array();
            foreach ($data as $key => $value) {
               // $value = escape($value);
                $values[] = "`$key`='$value'";
            }

            //insert
          
             $sql = "INSERT INTO `$table` SET " . implode(',', $values);
             mysql_query($sql) or die(mysql_error());
        }
    }
    /**
    * 
    */
    class Sign extends Database
    {
        function checkUserFirst($makh){
            $data = $this->get_a_record('khachhang','makh',$makh);
            if($data != null)
                if($data['matk']==null)
                    return false;
                else 
                { 
                  $active = $this->get_a_record('taikhoan','matk',$data['matk']);
                  if($active)
                    return true;
                  else return false;
                }
            return false;
        }
        function checkSignin($email,$pass){
            $data = $this->get_a_record('taikhoan','email',$email);
            $pass=md5($pass);

            if ($data!=null) {
              if($data['kichhoat']== true)
              {
                $matk=$data['matk'];
                $matkhau=$data['matkhau'];
                
                if ($matkhau==$pass) {
                    $makh = $this->get_a_record('khachhang','matk',$matk);
                    return $makh;
                }else return false;
              }else
                return false;
              }
              else return false;

        }
        function checkAvailableAccount($email){
            $sql ="SELECT matk FROM taikhoan WHERE email='$email'";
            $data = $this->get_a_record('taikhoan','email',$email);
            if ($data!=null) {
                return true;
            }
            else return false;
        }
    }
class Search extends database{
    
    function search_data($search_dt){
        $data =$this->get_all('sanpham');
        $data_search = array();
        $search='/'.strU($search_dt).'/';
        foreach ($data as $value){
            if(preg_match($search,strU($value['ten']))==TRUE ||
                preg_match($search,strU($value['mota']))==TRUE ||
                preg_match($search,strU($value['id']))==TRUE ||
                preg_match($search,strU($value['hinhanh']))==TRUE ||
                preg_match($search,strU($value['loaican']))==TRUE 
                )
            {
                $data_search[]=$value;                
            }
        }
        return $data_search;
    }
}
function strU($str){
        $str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
        $str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
        $str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
        $str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
        $str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
        $str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
        $str = preg_replace("/(đ)/", 'd', $str);
        $str = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $str);
        $str = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $str);
        $str = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $str);
        $str = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $str);
        $str = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $str);
        $str = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $str);
        $str = preg_replace("/(Đ)/", 'D', $str);
        $str = preg_replace("/[^A-Za-z0-9 ]/", '', $str);
        $str = preg_replace("/\s+/", ' ', $str);
        $str = trim($str);
        $str = strtolower($str);
        return $str;
}    
function pagination($url, $page, $total){
$adjacents = 2;
$prevlabel = "&lsaquo; Trước";
$nextlabel = "Tiếp &rsaquo;";
$out = '
<ul class="pagination">
     ';
     //first
     if ($page == 1) {
     $out.= '
     <li class="disabled"><span>Đầu</span></li>
     ';
     } else {
     $out.='
     <li><a href="'.$url.'">Đầu</a></li>
     ';
     }
     // previous
     if ($page == 1) {
     $out.= '
     <li class="disabled"><span>&Lt;</span></li>
     ';
     } elseif ($page == 2) {
     $out.='
     <li><a href="'.$url.'">&Lt;</a></li>
     ';
     } else {
     $out.='
     <li><a href="'.$url.'&amp;page='.($page - 1).'">&Lt;</a></li>
     ';
     }
     $pmin=($page>$adjacents)?($page - $adjacents):1;
     $pmax=($page<($total - $adjacents))?($page + $adjacents):$total;
     for ($i = $pmin; $i <= $pmax; $i++) {
     if ($i == $page) {
     $out.= '
     <li class="active"><span>'.$i.'</span></li>
     ';
     } elseif ($i == 1) {
     $out.= '
     <li><a href="'.$url.'">'.$i.'</a></li>
     ';
     } else {
     $out.= '
     <li><a href="'.$url. "&amp;page=".$i.'">'.$i. '</a></li>
     ';
     }
     }
     // next
     if ($page < $total) {
     $out.= '
     <li><a href="'.$url.'&amp;page='.($page + 1).'">&Gt;</a></li>
     ';
     } else {
     $out.= '
     <li class="disabled"><span>&Gt;</span></li>
     ';
     }
     //last
     if ($page < $total) {
     $out.= '
     <li><a href="'.$url.'&amp;page='.$total.'">Cuối</a></li>
     ';
     } else {
     $out.= '
     <li class="disabled"><span>Cuối</span></li>
     ';
     }
     $out.= '
</ul>
';
return $out;
}
 function get_from_to($table,$from,$to,$colum,$value, $select ='*'){
            if($colum && $value)
            $sql = "SELECT $select FROM `$table`  WHERE $colum = '$value' LIMIT $from,$to " ;
            else
            $sql = "SELECT $select FROM `$table` LIMIT $from,$to " ;
            $query = mysql_query($sql) or die(mysql_error());
            
            $data = array();
            if(mysql_num_rows($query) >0){
                while($row = mysql_fetch_assoc($query))
                    $data[]= $row;
                return $data;
            }
            else return null;
        }
function getCustomerCode(){
$str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
$length = 6;
for($s ='', $i =0, $z = strlen($str)-1; $i<$length; $x = rand(0,$z),$s.=$str[$x],$i++);
return $s;
}
//Lấy về 1 chuỗi 11 kĩ tự là thời gian hiện tại
function getOrderCode(){
return time();
}
function escape($str) {
return mysql_real_escape_string($str);
}
?>
<?php
    $search_model = new Search();
	$database =new Database();
    $sign = new Sign();
	$database->db_connect();
    $database->select_db();
?>