<div class="side-2">
                  <div class="block block-category-navigation">
                    <div class="title blue">
                        <strong>Danh mục</strong>
                      </div>
                      <div class="listbox">
                        <ul class="list">
                          <li class="<?php echo $active1;?> ">
                              <a href="sanpham.php?gioithieu">Cân Xe Tải</a>
                          </li>
                          <li class="<?php echo $active2;?> ">
                            <a href="sanpham.php?canthuongmai">Cân Thương Mại </a>
                          </li>
                          <li class="<?php echo $active3;?> ">
                            <a href="sanpham.php?cancongnghiep">Cân Công Nghiệp</a>
                          </li>
                          <li class="<?php echo $active4;?> ">
                            <a href="sanpham.php?thietbikhac">Thiết bị khác</a>
                          </li>
                        </ul>
                      </div>
                  </div>
                  <div class="block block-info">
                     <div class="title purple">
                        <strong>Số điện thoại hỗ trợ</strong>
                     </div>
                     <div class="listbox">
                        <ul>
                           <li style="text-align:center;">
                              <a href="">
                              Kinh doanh<br>
                              SĐT: 
                              </a>
                           </li>
                           <li style="text-align:center;">
                              <a href="">
                              Kỹ thuật<br>
                              SĐT:
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="block block-newsletter">
                     <div class="title">
                        <strong>Nhận bản tin</strong>
                     </div>
                     <div class="listbox">
                        <div id="newsletter-subscribe-block" class="newsletter-subscribe-block">
                           <span>Email đăng ký:</span>
                           <div class="newsletter-email">
                              <input id="newsletter-email" name="NewsletterEmail" type="text" value="">
                              <span class="field-validation-valid" data-valmsg-for="NewsletterEmail" data-valmsg-replace="true"></span>
                           </div>
                           <div class="buttons">
                              <input type="button" value="Xác nhận" id="newsletter-subscribe-button" class="button-1 newsletter-subscribe-button">
                              <span id="subscribe-loading-progress" style="display: none;" class="please-wait">Chờ đợi...</span>
                           </div>
                        </div>
                        <div id="newsletter-result-block" class="newsletter-result-block">
                        </div>
                     </div>
                     <script type="text/javascript">
                        $(document).ready(function () {
                            $('#newsletter-subscribe-button').click(function () {
                                
                                var email = $("#newsletter-email").val();
                                var subscribeProgress = $("#subscribe-loading-progress");
                                subscribeProgress.show();
                                $.ajax({
                                    cache: false,
                                    type: "POST",
                                    url: "/subscribenewsletter",
                                    data: { "email": email },
                                    success: function (data) {
                                        subscribeProgress.hide();
                                        $("#newsletter-result-block").html(data.Result);
                                         if (data.Success) {
                                            $('#newsletter-subscribe-block').hide();
                                            $('#newsletter-result-block').show();
                                         }
                                         else {
                                            $('#newsletter-result-block').fadeIn("slow").delay(2000).fadeOut("slow");
                                         }
                                    },
                                    error:function (xhr, ajaxOptions, thrownError){
                                        alert('Failed to subscribe.');
                                        subscribeProgress.hide();
                                    }  
                                });                
                                return false;
                            });
                        });
                     </script>
                  </div>
               </div>