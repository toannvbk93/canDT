        <div style="margin-top: 150px;margin-bottom:50px; margin-left:auto;margin-right:auto; width: 850px;height:300px;" >
        	<div id ="page">
					<div id="content">

							<div class="box_skitter box_skitter_large">
								<ul>
									<li><a href=""><img src="images/canxetai/slider1.png" class="circles" /></a></li>
									<li><a href=""><img src="images/canxetai/slider2.png" class="circlesInside" /></a></li>
									<li><a href=""><img src="images/canxetai/slider3.png" class="circlesRotate" /></a></li>
									<li><a href=""><img src="images/canxetai/slider4.png" class="cubeShow" /></a></li>	
								</ul>
						
							</div>
					</div>
				</div>
		</div>