<!DOCTYPE html>
<!-- saved from url=(0018)# -->
<html>
  <head>
    <?php if (!isset($title)){$title='Cân xe tải';}?>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?php echo $title;?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="./canxetai/styles.css" rel="stylesheet" type="text/css">
    <link href="./canxetai/responsive.css" rel="stylesheet" type="text/css">
    <link href="./canxetai/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" type="text/css">
    <link href="./canxetai/default.css" rel="stylesheet" type="text/css">
    <script async="" src="./canxetai/analytics.js"></script>
    <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script>
    <script type="text/javascript">bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });</script>
    <script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="js/analytics.js"></script>
    <script type="text/javascript" src='js/form.js'></script>

    <!--slider show-->
    <link type="text/css" href="css/skitter.styles.css" media="all" rel="stylesheet" />
    <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="js/jquery.skitter.min.js"></script>
    <link href="css/styles.css" type="text/css" media="all" rel="stylesheet" />
    <script type="text/javascript">
      $(document).ready(function() {
        $('.box_skitter_large').skitter({
          theme: 'default',
          dots: true, 
          preview: true,
          numbers_align: 'center'
        });
      });
    </script>
    <!--End slide show-->
    <!--chatbox-->

    <!--end chatbox-->
    <!--Powered by ToanNV-->
    <!--Copyright (c) 2015-->
  </head>
  <body>
  <div class="master-wrapper-page">
    <div class="master-wrapper-content">
      <div class="header">
        <div class="header-logo">
          <a href="./"><img title="" alt="Cân xe tải" src="./canxetai/logo.png"></a>
        </div>
        <div class="header-links-wrapper">
          <div class="header-links">
            <?php if(!$sign->checkUserFirst($_SESSION['makh'])){?>
              <ul>
                <li><a href="dangnhap.php" class="ico-login"><img src="images/log_in.png" height="20" width="20">Đăng nhập</a></li>
                <li><a href="dangky.php" class="ico-register"><img src="images/register.png" height="20" width="20">Đăng ký</a></li>
              </ul>
            <?php }else {?>
            <a href="logout.php">Thoát |</a>
            <?php echo 'Xin chào '.$_SESSION['email'];?>
            <?php if (isset($_SESSION['capdo'])&&$_SESSION['capdo']=='admin') {?>
            <a href="admin/index.php">Quản lý  |</a>
            <?php }}?>
          </div>
        </div>
        <div class="search-box">
          <form action="sanpham.php?search" method="POST">
             <span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
             <input type="text" class="search-box-text ui-autocomplete-input" id="small-searchterms" autocomplete="off" placeholder="Nhập tên sản phẩm" name="search_input">
             <input type="submit" class="btn blue" value="Tìm kiếm">             
          </form>
        </div>
      </div>
      <div class="header-menu">
        <div class="top-menu">
          <ul>
            <li class="has-sub"><a href=".">Trang chủ</a></li>
            <li class="has-sub"><a href="gioithieu.php">Giới thiệu</a></li>
            <li class="dropdown_column_product"><a href="sanpham.php">Sản Phẩm</a>
              <ul>
                <li>
                  <div class="row1">
                    <div class="cat">
                      <ol class="sub-list">
                        <li class="headline"><a href="sanpham.php?canxetai">Cân Xe Tải</a></li>
                        <li><a href="sanpham.php?canxetaisanchim">Cân xe tải sàn chìm</a></li>
                        <li><a href="sanpham.php?canxetaisannoi">Cân xe tải sàn nổi</a></li>
                        <li><a href="sanpham.php?canxetaixachtay">Cân xe tải xách tay</a></li>
                      </ol>
                    </div>
                  </div>
                </li>
              </ul>
            </li>
            
            
            <li class="dropdown_column_contact"><a href="lienhe.php" class="">Liên hệ</a></li>
            <li><a href="tintuc.php">Tin tức</a></li>
            <li class="has-sub"><a href="huongdan.php">Hướng dẫn</a></li>

          </ul>
        </div>
      </div>
      <?php require('template/scrollcontact.php');?>
