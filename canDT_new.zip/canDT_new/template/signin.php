<?php require('template/header.php');?>
<div class="master-wrapper-main">
               <?php
                  require('template/col1.php'); 
                ?>
    <div class="center-2">
    	<div class="page login-page">
    		<div class="page-title">
        		<h1>Xin chào, mời bạn đăng nhập !</h1>
    		</div>
    		<div class="page-body">
        		<div class="customer-blocks">
            	<div class="new-wrapper">
                	<div class="title">
                    	<strong>Nhập thông tin tài khoản</strong>
                	</div>
                	<div class="form-fields">
                		<?php 
                			if (isset($erroin)) {
                				echo $erroin;
                			}
                		?>
                		<br><br>
						<form action="dangnhap.php" method="post">
	                        <div class="message-error">
                            </div>
                        <div class="inputs">
                            <label for="Email">Email:</label>
                            <br><br>
                            <input autofocus="autofocus" class="email" data-val="true" data-val-email="Sai định dạng email" data-val-required="Nhập email" id="Email" name="Email" type="text" value="<?php if (isset($email)) {echo $email;}?>" />
                            <span class="field-validation-valid" data-valmsg-for="Email" data-valmsg-replace="true"></span>
                        </div>
                        <br><br>
                        <div class="inputs">
                            <label for="Password">Mật khẩu:</label><br><br>
                            <input class="password" id="Password" name="Password" type="password" value="<?php if (isset($pass)) {echo $pass;}?>"/>
                            <span class="field-validation-valid" data-valmsg-for="Password" data-valmsg-replace="true"></span>
                        </div>
                        <br><br>
                        <div class="inputs reversed">
                            <input data-val="true" data-val-required="'Remember Me' must not be empty." id="RememberMe" name="remeber" type="checkbox" value="true" /><input name="RememberMe" type="hidden" value="false" />
                            <label for="RememberMe">Ghi nhớ</label>
                        </div>
                        <div class="buttons">
                            <input class="btn green" type="submit" name="submit" value="Đăng nhập" />
                        </div>
				</form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

    
</div>

<?php require('template/footer.php');?>