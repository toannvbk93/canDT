<div class="center-2">
	<div class="page home-page">
	    <div class="page-body">
	    	<div id="ph-title">
	  			<div class="page-title">
     				<h1>Sản phẩm</h1> <hr>
     
  				</div>
			</div>
        <div class="product-grid home-page-product-grid">
           <div class="title">
           	<?php if(isset($loaican)){
           		echo 'Những sản phẩm: '.$loaican;
           	}elseif (isset($products_search)) {
           		echo 'Đây có phải sản phẩm bạn muốn tìm';
           	}else echo 'Những sản phẩm nổi bật';?>
        </div>
	   <?php
	     $sp=$database->get_all('sanpham');
	     if (isset($loaican)) {
	     	$search_input=$loaican;
	   		$products_search=$search_model->search_data($search_input);
	     	$sp=$products_search;
	     }
	     if (isset($products_search)) {
	     	$sp=$products_search;
	     	foreach ($sp as $key => $value) {?>
		         <div class='item-box'>
		         	<div class='product-item' data-productid='28'>
					 <div class='picture'>
					 	<a href="chitiet.php?id=<?php echo $value['hinhanh'];?>" title='Hiển thị thông tin chi tiết cho Cân bàn PB '>
					 		<img width='120' height='120' src="<?php echo $value['hinhanh'];?>">
					 	</a>
					 </div>
					 <div class='details'>
						<h2 class='product-title'>
						   <a href='#'><?php echo $value['ten'];?></a>
						</h2>
						 </div>
				  </div>
				  <a class="btn btn-warning" href="chitiet.php?id=<?php echo $value['hinhanh'];?>">Xem ngay</a>
			   </div>
			   <?php }
			   }elseif(isset($sp)&&!isset($loaican)){
			      foreach ($sp as $key => $value) {
			         if ($value['noibat']=='1') {?>
			         <div class='item-box'>
			         	<div class='product-item' data-productid='28'>
						 <div class='picture'>
						 	<a href="chitiet.php?id=<?php echo $value['hinhanh'];?>" title='Hiển thị thông tin chi tiết cho Cân bàn PB '>
						 		<img width='120' height='120' src="<?php echo $value['hinhanh'];?>">
						 	</a>
						 </div>
						<div class='details'>
							<h2 class='product-title'>
							   <a href='chitiet.php?id=<?php echo $value['hinhanh'];?>'><?php echo $value['ten'];?></a>
							</h2>
						</div>
					  </div>
					  <a class="btn btn-warning" href="chitiet.php?id=<?php echo $value['hinhanh'];?>">Xem ngay</a>
				   </div>
			         <?php
			         	
			         }}
			    }

		   ?>
		   </div>

        </div>
     </div>
  </div>
</div>