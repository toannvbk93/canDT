</div></div>
<div class="footer">
  <div class="footer-menu-wrapper">
    <div class="column information">
      <h3>Thông tin</h3>
      <ul>
         <li><a href="vanchuyen.php">Vận chuyển</a></li>
         <li><a href="chinhsach.php">Chính sách</a></li>
         <li><a href="dieukiensudung.php">Điều kiện sử dụng</a></li>
         <li><a href="gioithieu.php">Giới thiệu</a></li>
         <li><a href="lienhe.php">Liên hệ</a></li>
      </ul>
    </div>
    <div class="column customer-service">
      <h3>Dịch vụ khách hàng</h3>
      <ul>
        <li><a href="tintuc.php?tinmoi">Tin mới</a></li>
        <li><a href="chitiet.php?Sản phẩm vừa xem">Sản phẩm vừa xem</a></li>
        <li><a href="sanpham.php">Sản phẩm mới</a></li>
      </ul>
    </div>
    <div class="column address">
      <h3>Địa chỉ</h3>
      <ul>
        <li class="location"><strong>Địa chỉ</strong>: Tp.HCM</li>
        <li class="phone"><strong>Điện thoại</strong>: (84-8) 986.683.351</li>
        <li class="fax"><strong>Fax</strong>: </li>
        <li class="email"><strong>Email</strong>:thanhcasscale@gmail.com</li>
        <li class="website"><strong>Website</strong>:<a href="http://muabancanxetai.com">muabancanxetai.com</a></li>
        <li class="cas-global"></li>
      </ul>
    </div>
  </div>
<div class="footer-disclaimer">
   Bản quyền © 2015 ToanNV.
</div>
<a href="#" class="scrollToTop" ></a>
         <script type="text/javascript">
            $(document).ready(function () {
            
                //Check to see if the window is top if not then display button
                $(window).scroll(function () {
                    if ($(this).scrollTop() > 100) {
                        $('.scrollToTop').fadeIn();
                    } else {
                        $('.scrollToTop').fadeOut();
                    }
                });
            
                //Click event to scroll to top
                $('.scrollToTop').click(function () {
                    $('html, body').animate({ scrollTop: 0 }, 800);
                    return false;
                });
            
            });
         </script>
</div>
</body>
</html>

