<div class="contact-wrap">
	<a href="#contact-box" class="contact-button"><img src="images/contact.png" width="60" alt="Contact"></a>
</div>
<?php
if (isset($_POST['submit'])) {
	if (isset($_POST['username'])&&isset($_POST['email'])&&isset($_POST['phone_number'])&&isset($_POST['mess'])) {
		$ten=escape($_POST['username']);
		$email=escape($_POST['email']);
		$sdt=escape($_POST['phone_number']);
		$tinnhan=escape($_POST['mess']);
		$makh=$_SESSION['makh'];
		$khachhang=array('email'=>$email, 'hoten'=>$ten, 'sdt'=>$sdt,'tinnhan'=>$tinnhan,'makh'=>$makh);
		$database->save('khachhang',$khachhang);
	}
}
?>
<!-- BEGIN: contact -->
<div id="contact-box" class="contact">
	 <p class="tittle"> Liên hệ với chúng tôi</p>
	<a href="#" class="close"><img src="images/close2.png" class="img-close" title="Close Window" alt="Close" /></a>
	<form method="post" class="contact-content" action="">
		 Mời nhập đầy đủ các thông tin!<br>
		<label class="username">
			<span>Họ tên</span>
			<input id="username" name="username" value="" type="text" autocomplete="on" placeholder="Your Name" required='required'>
		</label>
		<label class="email">
			<span>Email</span>
			<input id="email" name="email" value="" type="email" autocomplete="on" placeholder="Email" required='required'>
		</label>
		<label class="phone_number">
			<span>Số điện thoại</span>
			<input id="phone_number" name="phone_number" value="" type="text" pattern ="[0-9]{10,11}" required="required" placeholder="Phone number">
		</label>
		<label class="mess">
			<span>Tin nhắn</span>
			<input id="mess" name="mess" value="" type="text" autocomplete="on" placeholder="Your messenger" required='required'>
		</label>
		<button class="button submit-button" type="submit" name="submit">Send</button>     
	</form>
</div>
<!-- END: contact -->
